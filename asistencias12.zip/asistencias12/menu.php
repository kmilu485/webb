<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles1.css">
    <title>Menu Principal</title>
</head>
<body>
    <h2>Menu Principal</h2>
    <ul>
        <li><a href="registroasistencia.php">Registrar Asistencias</a></li>
        <li><a href="registroestudiantes.php">Registrar Estudiantes</a></li>
        <li><a href="actualizaciondeestudiantes.php">Actualizar Estudiantes</a></li>
        <li><a href="eliminaciondeestudiantes.php">Eliminar Estudiantes</a></li>
        <li><a href="registrodegrado.php">Registrar Grados</a></li>
        <li><a href="actualizaciondegrado.php">Actualizar Grados</a></li>
        <li><a href="eliminaciondegrado.php">Eliminar Grados</a></li>
        <li><a href="index.html">Salir</a></li>
    </ul>
</body>
</html>